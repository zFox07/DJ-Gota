exports.run = async(client, message) => {
    const channel = message.member.voice.channel;
    if (!channel) return message.channel.send('Tens que estar numa chamada para usares este comando!');
    let queue = message.client.queue.get(message.guild.id)
    if(!queue) return message.channel.send({
        embed: {
            description: 'Musica todos os dias às 9h00 na RFM!',
            color: 'RED'
        }
    })
    message.react('✅')
    queue.songs = []
    queue.connection.dispatcher.end('Musica todos os dias às 9h00 na RFM!')
}