const { MessageEmbed } = require('discord.js')
exports.run = async(client, message) => {
    const channel = message.member.voice.channel;
    if (!channel) return message.channel.send('Tem que estar numa chamada para usar este comando!');
    let queue = message.client.queue.get(message.guild.id)
    if(!queue) return message.channel.send({
        embed:{
            title: 'Não está a tocar nada agora!'
        }
    })
    message.channel.send({
        embed:{
            title: 'Agora a Tocar!',
            description: queue.songs[0].title + ' Pedido por: ' + '<@' + queue.songs[0].requester + '>',
            color: 'RED',
            thumbnail: queue.songs[0].thumbnail
        }
    })
}