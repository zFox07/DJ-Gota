exports.run = async(client, message) => {
    const channel = message.member.voice.channel;
    if (!channel) return message.channel.send('Você tem que estar numa chamada para fazer este comando!');
    let queue = message.client.queue.get(message.guild.id)
    if(!queue){ return message.channel.send({
        embed: {
            description: 'Não existe nenhuma musica a seguir desta para eu dar skip! `Use /play <Nome da musica> para adicionar uma musica`',
            color: 'RED'
        }
    })
}
    if(queue.songs.length !== 0) {
        message.react('✅')
        queue.connection.dispatcher.end('Musica skipada!')
    }
}