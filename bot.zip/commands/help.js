const Discord = require("discord.js");

module.exports = {
    name: "help com reação ",
    description: "clique na reação, e a mensagem será editada :)",
    author: "Eduzinho",

run: async(client, message, args) => { //embed do painel inicial
    let embed = new Discord.MessageEmbed()
    .setTitle(`Commands panel`)
    .setThumbnail(message.author.displayAvatarURL())
    .setDescription(`Chose your **language**:

\n🔵 **English** \n🟢 **Poruguese** \n🔴 **Germen** \n🟡 **French**
⠀`)
    .setFooter(`${message.author.tag}`)
    .setColor("RED")    
    message.channel.send(`${message.author}`, embed).then(msg => {
      msg.react("◀️")
      msg.react("🔵")
      msg.react("🟢")
      msg.react("🔴")
      msg.react("🟡")

      let filtro0 = (r, u) => r.emoji.name === '◀️' && u.id === message.author.id;
      let filtro1 = (r, u) => r.emoji.name === '🔵' && u.id === message.author.id;
      let filtro2 = (r, u) => r.emoji.name === '🟢' && u.id === message.author.id;
      let filtro3 = (r, u) => r.emoji.name === '🔴' && u.id === message.author.id;
      let filtro4 = (r, u) => r.emoji.name === '🟡' && u.id === message.author.id;
      

      let coletor0 = msg.createReactionCollector(filtro0);
      let coletor = msg.createReactionCollector(filtro1);
      let coletor2 = msg.createReactionCollector(filtro2);
      let coletor3 = msg.createReactionCollector(filtro3);
      let coletor4 = msg.createReactionCollector(filtro4);

      coletor0.on("collect", c => { //embed do painel inicial (editada)

        let edu = new Discord.MessageEmbed()
      .setTitle(`Commands Panel`)
      .setThumbnail(message.author.displayAvatarURL())
      .setDescription(`Veja os comandos:

\n🔵 English \n🟢 Portuguese \n🔴 Germen \n🟡 French
⠀`)
      .setFooter(`${message.author.tag}`)
      .setColor("RED")   
        
     
        msg.edit(`${message.author}`, edu)
      })


      coletor.on("collect", c => { //embed do painel de utilidade (editada)

        let fera = new Discord.MessageEmbed()
        .setTitle(`🔵 **English** 🔵`)
        .setThumbnail(message.author.displayAvatarURL())
        .setFooter(`${message.author.tag}`)
        .setDescription(`➔**/play** or **/p** <music>
        ➔**/skip** -> skip the music
        ➔**/pause** -> pause the music
        ➔**/resume** -> resume the music
        ➔**/lyric** -> Lyrics of music
        ➔**/disconnect** -> bot disconnect 
        ➔**/queue** -> Queue of musics 
        ➔**/shuffle** -> Shuffle the queue
        ➔**/np** -> Informations of music
        ➔**/volume** -> Configurate the volume of musics
        \n⠀`)
        .setColor("RED")
        

        msg.edit(`${message.author}`, fera)
      })

      coletor2.on("collect", c => { //embed do painel de moderação (editada)

        let fera = new Discord.MessageEmbed()
        .setTitle(`🟢 **Portuguese** 🟢`)
        .setThumbnail(message.author.displayAvatarURL())
        .setFooter(`${message.author.tag}`)
        .setDescription(`➔ **/play** ou **/p** <música>
        ➔ **/skip** -> pular a música
        ➔ **/pause** -> pausar a música
        ➔ **/resume** -> retomar a música
        ➔ **/lyric** -> Letras de música
        ➔ **/sair** -> desconexão de bot
        ➔ **/queue** -> Fila de músicas
        ➔ **/shuffle** -> Ordem aleatória da fila
        ➔ **/np** -> Informações da música
        ➔ **/volume** -> Configurar o volume das músicas\n⠀`)
        .setColor("RED")
        

        msg.edit(`${message.author}`, fera)
      })

      coletor3.on("collect", c => { //embed do painel de diversão (editada)

        let edu = new Discord.MessageEmbed()
        .setTitle(`🔴 **Germen** 🔴`)
        .setThumbnail(message.author.displayAvatarURL())
        .setFooter(`${message.author.tag}`)
        .setDescription(`➔**/play** oder **/p** <music>
        ➔**/skip** -> überspringe die Musik
        ➔**/pause** -> pausiere die Musik
        ➔**/resume** -> Musik fortsetzen
        ➔**/lyric** -> Songtexte
        ➔**/disconnect** -> Bot trennen
        ➔**/queue** -> Warteschlange der Musik
        ➔**/shuffle** -> Mische die Warteschlange
        ➔**/np** -> Informationen zur Musik
        ➔**/volume** -> Konfiguriere die Lautstärke von Musik
        \n⠀`)
        .setColor("RED")

        msg.edit(`${message.author}`, edu)
      })

      coletor4.on("collect", c => { //embed de outros cmds (editada)

        let ferauwu = new Discord.MessageEmbed()
        .setTitle(`🟡 **French** 🟡`)
        .setThumbnail(message.author.displayAvatarURL())
        .setFooter(`${message.author.tag}`)
        .setDescription(`➔**/play** ou **/p** <musique>
        ➔**/skip** -> sauter la musique
        ➔**/pause** -> mettre la musique en pause
        ➔**/resume** -> reprendre la musique
        ➔**/lyric** -> Paroles de musique
        ➔**/disconnect** -> bot déconnecter
        ➔**/queue** -> File d'attente des musiques
        ➔**/shuffle** -> Mélanger la file d'attente
        ➔**/np** -> Informations sur la musique
        ➔**/volume* -> Configurer le volume des musiques
        \n⠀`)
        .setColor("RED")

        msg.edit(`${message.author}`, ferauwu)
      })
    })
  }
}//by eduzinho ;)