const config = {
    token: 'ODYxMzU3Njg5OTY2OTUyNDc4.YOIn3A.uDrSE1MIhVSE8H92hhMSw4hlw0A',
    prefix: '.'
}
module.exports = config;