module.exports = (client) => {
    console.log('Login as' + client.user.tag)
    console.log ('Estou pronto caralhoh!')
}